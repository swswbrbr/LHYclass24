package kr.or.ksmart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import kr.or.ksmart.dto.Member;

public class Mdao {
	DataSource ds;
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	Member m = null;
	ArrayList<Member> alm = null;
	
	public Mdao() {
		System.out.println("06 Mdao 생성자 메서드 실행");
		try{
			Context init = new InitialContext();
			System.out.println(init + "<-- init BoardDAO() ");
	  	    ds = (DataSource) init.lookup("java:comp/env/jdbc/OracleDB222");
	  		
		}catch(Exception ex){
			System.out.println("DB 연결 실패 : " + ex);
			return;
		}
	}
	//08 session
	public Member mGetForSession(String id) throws ClassNotFoundException, SQLException{
		System.out.println("06_08_mGetForSession Mdao.java");
		conn = ds.getConnection();		
		pstmt = conn.prepareStatement(
				"select ora_id,ora_level,ora_name from oracle_member where ora_id=?");
		pstmt.setString(1, id);
		rs = pstmt.executeQuery();	
		if(rs.next()){
			m = new Member();
			m.setORA_ID(rs.getString("ora_id"));
			m.setORA_LEVEL(rs.getString("ora_level"));
			m.setORA_NAME(rs.getString("ora_name"));
		}
		if (rs != null) try { rs.close(); } catch(SQLException ex) {}
		if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
		if (conn != null) try { conn.close(); } catch(SQLException ex) {}
		return m;
	}
	
	//07 logincheck
	public int isMember(String id, String pw) throws SQLException {
		System.out.println("06_07_isMember Mdao.java");
		int re = 0;
		conn = ds.getConnection();		
		pstmt = conn.prepareStatement("select * from oracle_member where ora_id=?");
		pstmt.setString(1, id);
		rs = pstmt.executeQuery();
		if(rs.next()){
			if(pw.equals(rs.getString("ora_pw"))){
				re = 0;
			}else{
				re = -1;
			}
		}else{
			re = -1;
		}
		if (rs != null) try { rs.close(); } catch(SQLException ex) {}
		if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
		if (conn != null) try { conn.close(); } catch(SQLException ex) {}
		return re;	
	}
	//06 searchForm 메서드
	public ArrayList<Member> mSearch(String search) throws ClassNotFoundException, SQLException{
		System.out.println("06_06_mSearch Mdao.java");
		alm = new ArrayList<Member>();
		System.out.println(alm + "<-- alm 111");
		conn = ds.getConnection();
		System.out.println(conn + "<-- conn mSearch메서드 db연결");
		String query = "select * from oracle_member where ora_id=? or ora_level=? or ora_name=? or ora_email=?";
		pstmt = conn.prepareStatement(query);
		pstmt.setString(1, search);
		pstmt.setString(2, search);
		pstmt.setString(3, search);
		pstmt.setString(4, search);
		rs = pstmt.executeQuery();	
		while(rs.next()){
			m = new Member();
			m.setORA_ID(rs.getString("ora_id"));
			m.setORA_PW(rs.getString("ora_pw"));
			m.setORA_LEVEL(rs.getString("ora_level"));
			m.setORA_NAME(rs.getString("ora_name"));
			m.setORA_EMAIL(rs.getString("ora_email"));
			alm.add(m);
			System.out.println(alm + "<-- alm 222");			
		}
		if (rs != null) try { rs.close(); } catch(SQLException ex) {}
		if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
		if (conn != null) try { conn.close(); } catch(SQLException ex) {}
		return alm;

	}
	
	//05 delete 처리 메서드
	public void mDelete(String id) throws ClassNotFoundException, SQLException{
		System.out.println("06_05_mDelete Mdao.java");
		conn = ds.getConnection();
		System.out.println(conn + "<-- conn mDelete메서드 db연결");
		pstmt = conn.prepareStatement("DELETE FROM oracle_member WHERE ora_id=?");
		System.out.println(pstmt + "<-- pstmt 1");
		//insert into tb_member values('id001','pw001','������','ȫ01','email01');
		pstmt.setString(1, id);
		System.out.println(pstmt + "<-- pstmt 2");
		pstmt.executeUpdate();
		if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
		if (conn != null) try { conn.close(); } catch(SQLException ex) {}
	}
	
	//04 update 처리 메서드
	public void mUpdate(Member m) throws ClassNotFoundException, SQLException{
		System.out.println("06_04_mUpdate Mdao.java");
		conn = ds.getConnection();
		System.out.println(conn + "<-- conn mUpdate메서드 db연결");
		pstmt = conn.prepareStatement("UPDATE oracle_member SET ora_pw=?,ora_level=?,ora_name=?,ora_email=? WHERE ora_id=?");
		System.out.println(pstmt + "<-- pstmt 1");
		pstmt.setString(1, m.getORA_PW());
		pstmt.setString(2, m.getORA_LEVEL());
		pstmt.setString(3, m.getORA_NAME());
		pstmt.setString(4, m.getORA_EMAIL());
		pstmt.setString(5, m.getORA_ID());
		System.out.println(pstmt + "<-- pstmt 2");
		pstmt.executeUpdate();
		if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
		if (conn != null) try { conn.close(); } catch(SQLException ex) {}
		
	}
	
	//03 select for update 메서드
	public Member mSelectforUpdate(String mid) throws ClassNotFoundException, SQLException{
		System.out.println("06_03_mSelectforUpdate Mdao.java");
		conn = ds.getConnection();
		System.out.println(conn + "<-- conn mSelectforUpdate메서드 db연결");
		pstmt = conn.prepareStatement("select * from oracle_member where ora_id=?");
		pstmt.setString(1, mid);
		rs = pstmt.executeQuery();	
		if(rs.next()){
			m = new Member();
			m.setORA_ID(rs.getString("ora_id"));
			m.setORA_PW(rs.getString("ora_pw"));
			m.setORA_LEVEL(rs.getString("ora_level"));
			m.setORA_NAME(rs.getString("ora_name"));
			m.setORA_EMAIL(rs.getString("ora_email"));
		}
		if (rs != null) try { rs.close(); } catch(SQLException ex) {}
		if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
		if (conn != null) try { conn.close(); } catch(SQLException ex) {}
		return m;
	}
	
	
	//02 mlist 메서드 
	public ArrayList<Member> mAllSelect() throws ClassNotFoundException, SQLException{
		System.out.println("06_02_mAllSelect Mdao.java");
		alm = new ArrayList<Member>();
		System.out.println(alm + "<-- alm 111");
		conn = ds.getConnection();	
		System.out.println(conn + "<-- conn mAllSelect메서드 db연결");
		pstmt = conn.prepareStatement("select * from oracle_member");
		rs = pstmt.executeQuery();	
		while(rs.next()){
			m = new Member();
			m.setORA_ID(rs.getString("ora_id"));
			m.setORA_PW(rs.getString("ora_pw"));
			m.setORA_LEVEL(rs.getString("ora_level"));
			m.setORA_NAME(rs.getString("ora_name"));
			m.setORA_EMAIL(rs.getString("ora_email"));
			alm.add(m);		
			System.out.println(alm + "<-- alm 222");			
		}
		if (rs != null) try { rs.close(); } catch(SQLException ex) {}
		if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
		if (conn != null) try { conn.close(); } catch(SQLException ex) {}
		return alm;
	}
	
	//01 insert 메서드
	public void mInsert(Member m) throws SQLException{
		System.out.println("06_01_mInsert Mdao.java");
		conn = ds.getConnection();
		System.out.println(conn+" <-- conn mInsert메서드 db연결");
		pstmt = conn.prepareStatement(
				"INSERT INTO oracle_member VALUES (?, ?, ?, ?, ?)");
		System.out.println(pstmt + "<-- pstmt 1");
		pstmt.setString(1, m.getORA_ID());
		pstmt.setString(2, m.getORA_PW());
		pstmt.setString(3, m.getORA_LEVEL());
		pstmt.setString(4, m.getORA_NAME());
		pstmt.setString(5, m.getORA_EMAIL());
		System.out.println(pstmt + "<-- pstmt 2");
		pstmt.executeUpdate();
		if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
		if (conn != null) try { conn.close(); } catch(SQLException ex) {}
	}

	

}
