package kr.or.ksmart.dto;

public class Member {
	private String ORA_ID;
	private String ORA_PW;
	private String ORA_LEVEL;
	private String ORA_NAME;
	private String ORA_EMAIL;
	
	public String getORA_ID() {
		return ORA_ID;
	}
	public void setORA_ID(String oRA_ID) {
		System.out.println(oRA_ID+" <-- setORA_ID Member.java");
		ORA_ID = oRA_ID;
	}
	public String getORA_PW() {
		return ORA_PW;
	}
	public void setORA_PW(String oRA_PW) {
		System.out.println(oRA_PW+" <-- setORA_PW Member.java");
		ORA_PW = oRA_PW;
	}
	public String getORA_LEVEL() {
		return ORA_LEVEL;
	}
	public void setORA_LEVEL(String oRA_LEVEL) {
		System.out.println(oRA_LEVEL+" <-- setORA_LEVEL Member.java");
		ORA_LEVEL = oRA_LEVEL;
	}
	public String getORA_NAME() {
		return ORA_NAME;
	}
	public void setORA_NAME(String oRA_NAME) {
		System.out.println(oRA_NAME+" <-- setORA_NAME Member.java");
		ORA_NAME = oRA_NAME;
	}
	public String getORA_EMAIL() {
		return ORA_EMAIL;
	}
	public void setORA_EMAIL(String oRA_EMAIL) {
		System.out.println(oRA_EMAIL+" <-- setORA_EMAIL Member.java");
		ORA_EMAIL = oRA_EMAIL;
	}
	
	
}
