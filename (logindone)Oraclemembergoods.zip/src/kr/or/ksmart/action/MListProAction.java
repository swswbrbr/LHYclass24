package kr.or.ksmart.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ksmart.Inter.MActionInterFace;
import kr.or.ksmart.dao.Mdao;
import kr.or.ksmart.dto.Member;
import kr.or.ksmart.forward.MActionForward;

public class MListProAction implements MActionInterFace {

	@Override
	public MActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("05_02_execute MListProAction.java");
		
		//01단계
		Mdao dao = new Mdao();
		ArrayList<Member> alm = dao.mAllSelect();
		
		//02단계
		request.setAttribute("alm", alm);
		
		//03단계
		MActionForward forward = new MActionForward();
		forward.setRedirect(false);
		forward.setPath("/Mlist/m_list.jsp");
		
		//04단계
		return forward;
	}

}
