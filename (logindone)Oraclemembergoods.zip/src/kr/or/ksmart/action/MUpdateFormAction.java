package kr.or.ksmart.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ksmart.Inter.MActionInterFace;
import kr.or.ksmart.dao.Mdao;
import kr.or.ksmart.dto.Member;
import kr.or.ksmart.forward.MActionForward;

public class MUpdateFormAction implements MActionInterFace {

	@Override
	public MActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("05_03_execute MUpdateFormAction.java");
		Mdao dao = new Mdao();
		Member mup = dao.mSelectforUpdate(request.getParameter("send_id"));
		
		request.setAttribute("mup", mup);
		
		MActionForward forward = new MActionForward();
		forward.setRedirect(false);
		forward.setPath("/Mup/m_update_form.jsp");
		return forward;
	}

}
