package kr.or.ksmart.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.or.ksmart.Inter.MActionInterFace;
import kr.or.ksmart.forward.MActionForward;

public class MLogoutAction implements MActionInterFace {

	@Override
	public MActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("05_06_execute MLogoutAction.java");
		HttpSession session = request.getSession();
		session.invalidate();
		MActionForward forward = new MActionForward();
		forward.setRedirect(false);
		forward.setPath("/index.ksmart");
		return forward;
	}

}
