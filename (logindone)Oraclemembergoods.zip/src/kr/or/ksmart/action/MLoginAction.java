package kr.or.ksmart.action;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.or.ksmart.Inter.MActionInterFace;
import kr.or.ksmart.dao.Mdao;
import kr.or.ksmart.dto.Member;
import kr.or.ksmart.forward.MActionForward;

public class MLoginAction implements MActionInterFace {

	@Override
	public MActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("05_05_execute MLoginAction.java");
		MActionForward forward = new MActionForward();
	 	
	 	HttpSession session=request.getSession();
		Mdao dao=new Mdao();
   		
   		int result=-1;
   		
   		String id = request.getParameter("id");
   		String pw = request.getParameter("pw");
   		result=dao.isMember(id, pw);
   		
   		
   		if(result==0){
   			response.setContentType("text/html;charset=euc-kr");
	   		PrintWriter out=response.getWriter();
	   		//out.println("<script>");
	   		//out.println("alert('로그인 성공.');");
	   		//out.println("location.href='./index.ksmart';");
	   		//out.println("</script>");
	   		//out.close();
	   		
   		}else if(result==-1){
   			response.setContentType("text/html;charset=euc-kr");
	   		PrintWriter out=response.getWriter();
	   		out.println("<script>");
	   		out.println("alert('로그인 실패.');");
	   		out.println("location.href='./index.ksmart';");
	   		out.println("</script>");
	   		out.close();
	   	}
   		
   		Member m = dao.mGetForSession(id);
   		session.setAttribute("id", m.getORA_ID());
   		session.setAttribute("level", m.getORA_LEVEL());
   		forward.setRedirect(false);
   		forward.setPath("/index.ksmart");
   		return forward;
	}
}
