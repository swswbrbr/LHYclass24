package kr.or.ksmart.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ksmart.Inter.MActionInterFace;
import kr.or.ksmart.dao.Mdao;
import kr.or.ksmart.dto.Member;
import kr.or.ksmart.forward.MActionForward;

public class MInsertProAction implements MActionInterFace {

	@Override
	public MActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("05_01_execute MInsertProAction.java");
		request.setCharacterEncoding("euc-kr");
		//01단계: 화면에서 입력한 값들을 받아서 확인한다.
		String id = request.getParameter("m_id");
		String pw = request.getParameter("m_pw");
		String level = request.getParameter("m_level");
		String name = request.getParameter("m_name");
		String email = request.getParameter("m_email");
		System.out.println(id+" <-- id MInsertProAction.java");
		System.out.println(pw+" <-- pw MInsertProAction.java");
		System.out.println(level+" <-- level MInsertProAction.java");
		System.out.println(name+" <-- name MInsertProAction.java");
		System.out.println(email+" <-- email MInsertProAction.java");
		
		//02단계: Vo 또는 DTO객체에 셋팅(선택)
		Member m = new Member();
		m.setORA_ID(id);
		m.setORA_PW(pw);
		m.setORA_LEVEL(level);
		m.setORA_NAME(name);
		m.setORA_EMAIL(email);
		
		//03단계: DAO내 insert메서드 호출시 vo객체 주소값 입력(리턴선택)
		Mdao dao = new Mdao();
		dao.mInsert(m);
		
		//04단계: MActionForward 객체내 셋팅(true 또는 false값과 경로)
		MActionForward forward = new MActionForward();
		forward.setRedirect(true);
		forward.setPath(request.getContextPath()+"/Mlist/m_list.ksmart");
		
		//05단계: 메서드 호출한 곳으로 주소값 리턴
		return forward;
	}

}
