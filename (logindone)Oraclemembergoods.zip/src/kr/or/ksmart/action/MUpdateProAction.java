package kr.or.ksmart.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ksmart.Inter.MActionInterFace;
import kr.or.ksmart.dao.Mdao;
import kr.or.ksmart.dto.Member;
import kr.or.ksmart.forward.MActionForward;

public class MUpdateProAction implements MActionInterFace {

	@Override
	public MActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("05_04_execute MUpdateFormAction.java");
		Member m = new Member();
		m.setORA_ID(request.getParameter("m_id"));
		m.setORA_PW(request.getParameter("m_pw"));
		m.setORA_LEVEL(request.getParameter("m_level"));
		m.setORA_NAME(request.getParameter("m_name"));
		m.setORA_EMAIL(request.getParameter("m_email"));
		
		Mdao dao = new Mdao();
		dao.mUpdate(m);
		MActionForward forward = new MActionForward();
		forward.setRedirect(false);
		forward.setPath("/Mlist/m_list.ksmart");
		return forward;
	}

}
