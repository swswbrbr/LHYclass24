package kr.or.ksmart.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ksmart.Inter.MActionInterFace;
import kr.or.ksmart.dao.Mdao;
import kr.or.ksmart.dto.Member;
import kr.or.ksmart.forward.MActionForward;

public class MSearchFormAction implements MActionInterFace {

	@Override
	public MActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("05_05_execute MUpdateFormAction.java");
		request.setCharacterEncoding("euc-kr");
		String search = request.getParameter("search");
		Mdao dao = new Mdao();
		ArrayList<Member> alm = dao.mSearch(search);
		request.setAttribute("alm", alm);
		MActionForward forward = new MActionForward();
		forward.setRedirect(false);
		forward.setPath("/Msearch/m_search_list.jsp");
		return forward;
	}

}
