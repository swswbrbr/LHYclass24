package kr.or.ksmart.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ksmart.Inter.MActionInterFace;
import kr.or.ksmart.dao.Mdao;
import kr.or.ksmart.forward.MActionForward;

public class MDeleteProAction implements MActionInterFace {

	@Override
	public MActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String id = request.getParameter("send_id");
		
		Mdao dao = new Mdao();
		dao.mDelete(id);
		MActionForward forward = new MActionForward();
		forward.setRedirect(false);
		forward.setPath("/Mlist/m_list.ksmart");
		
		return forward;
	}

}
