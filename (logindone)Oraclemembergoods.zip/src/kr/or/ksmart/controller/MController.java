package kr.or.ksmart.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ksmart.Inter.MActionInterFace;
import kr.or.ksmart.action.MDeleteProAction;
import kr.or.ksmart.action.MInsertProAction;
import kr.or.ksmart.action.MListProAction;
import kr.or.ksmart.action.MLoginAction;
import kr.or.ksmart.action.MLogoutAction;
import kr.or.ksmart.action.MSearchFormAction;
import kr.or.ksmart.action.MUpdateFormAction;
import kr.or.ksmart.action.MUpdateProAction;
import kr.or.ksmart.forward.MActionForward;

@WebServlet("/MController")
public class MController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MController() {
        super();
    }
    
    public void mProcess(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
    	 System.out.println("03 doProcess 메서드 MController.java");
		 String RequestURI=request.getRequestURI();
		 String contextPath=request.getContextPath();
		 String command=RequestURI.substring(contextPath.length());
		 System.out.println(RequestURI + "<-- RequestURI MController.java");
		 System.out.println(contextPath + "<-- contextPath MController.java");
		 System.out.println(contextPath.length() + "<-- contextPath.length() MController.java");
		 System.out.println(command + "<-- command MController.java");
		 System.out.println("----------MController.java----------------");
		 System.out.println();
		 MActionForward forward=null;
		 MActionInterFace action=null;
		
		 
		 if(command.equals("/index.ksmart")){
			 System.out.println("04_01_/index.ksmart");
				forward=new MActionForward();
				forward.setRedirect(false);
				forward.setPath("./main.jsp");
			
			}else if(command.equals("/Min/m_insert_form.ksmart")){
				System.out.println("04_02_/Min/m_insert_form.ksmart");
				forward=new MActionForward();
				forward.setRedirect(false);
				forward.setPath("./m_insert_form.jsp");
			}else if(command.equals("/Min/m_insert_pro.ksmart")){
				System.out.println("04_03_/Min/m_insert_pro.ksmart");
				action = new MInsertProAction();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else if(command.equals("/Mlist/m_list.ksmart")){
				System.out.println("04_04_/Mlist/m_list.ksmart");
				action = new MListProAction();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else if(command.equals("/Mup/m_update_form.ksmart")){
				System.out.println("04_05_/Mup/m_update_form.ksmart");
				action = new MUpdateFormAction();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else if(command.equals("/Mup/m_update_pro.ksmart")){
				System.out.println("04_06_/Mup/m_update_pro.ksmart");
				action = new MUpdateProAction();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else if(command.equals("/Mdel/m_delete_pro.ksmart")){
				System.out.println("04_07_/Mdel/m_delete_pro.ksmart");
				action = new MDeleteProAction();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else if(command.equals("/Msearch/m_search_list.ksmart")){
				System.out.println("04_08_/Msearch/m_search_list.ksmart");
				action = new MSearchFormAction();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else if(command.equals("/MLogin.ksmart")){
				System.out.println("04_09_/MLogin.ksmart");
				action = new MLoginAction();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}	
			}else if(command.equals("/logout.ksmart")){
				System.out.println("04_10_/logout.ksmart");
				action = new MLogoutAction();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		
//forward 할 것인가? redirect 할 것인가?		
		if(forward != null){
			if(forward.isRedirect()){
				response.sendRedirect(forward.getPath());
			}else{
				RequestDispatcher dispatcher = request.getRequestDispatcher(forward.getPath());
				System.out.println(forward.getPath() + "<--- forward.getPath()[jsp 이동경로]  MController.java");
				System.out.println();
				dispatcher.forward(request, response);
			}
		}
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("01 doGet 실행 MController.java");
		mProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("02 doPost 실행 MController.java");
		request.setCharacterEncoding("euc-kr");
		mProcess(request, response);
	}

}
